# API Cetification

## About

Example APIs that compile the best practices of the existing protocols in Inditex:

- REST
- gRPC
- AsyncAPI
- GraphQL

## Main Goal

This repository is divided into:

- **Templates** that help designers to have a starting point in the design
  of their APIs.
- **API examples** for the different protocols that cover the E2E of an API
  implementation, from its definition to its implementation and
  deployment in Inditex environments.

## Context

As a part of the API Team initiative on API Contract Design Best Practices.

## Usage

API-First designers

## Documentation

[API Designer - Event checklist](https://api-white-paper.docs.inditex.dev/apidsg/latest/features/asyncapi-checklist.html)

[API Designer - GraphQL checklist](https://api-white-paper.docs.inditex.dev/apidsg/latest/features/graphql-checklist.html)

[API Designer - gRPC checklist](https://api-white-paper.docs.inditex.dev/apidsg/latest/features/grpc-checklist.html)

[API Designer - REST checklist](https://api-white-paper.docs.inditex.dev/apidsg/latest/features/rest-checklist.html)
